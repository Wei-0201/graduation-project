"""Match vertical arrow silhouettes against the project's six sign references."""
from pathlib import Path

import cv2
import numpy as np


SIZE = (40, 56)
ARROW_HITS = 3


def silhouette(contour):
    x, y, w, h = cv2.boundingRect(contour)
    mask = np.zeros((h, w), dtype=np.uint8)
    cv2.drawContours(mask, [contour], -1, 255, cv2.FILLED, offset=(-x, -y))
    return cv2.resize(mask, SIZE, interpolation=cv2.INTER_AREA) >= 128


class SpeedArrowDetector:
    def __init__(self):
        with np.load(str(Path(__file__).with_name('speed_arrow_templates.npz'))) as data:
            self.templates = data['masks']
            self.directions = tuple(data['directions'])

    def detect(self, image):
        # The enclosed outline of the blue arrow yields the same solid
        # silhouette as the red or black arrows. Ignore the outside sign frame.
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        mask = cv2.inRange(gray, 0, 145)
        contours = cv2.findContours(mask, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)[-2]
        height, width = gray.shape
        matches = {}
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            if not (h >= 30 and w >= 22 and .52 <= w/h <= 1.02
                    and x > 1 and y > 1 and x+w < width-1 and y+h < height-1
                    and .32 <= cv2.contourArea(contour)/(w*h) <= .74):
                continue
            candidate = silhouette(contour)
            scores = (np.count_nonzero(candidate & self.templates, axis=(1, 2))
                      / np.count_nonzero(candidate | self.templates, axis=(1, 2)))
            best = int(np.argmax(scores))
            direction = str(self.directions[best])
            opposite = max(score for score, label in zip(scores, self.directions)
                           if label != direction)
            score = float(scores[best])
            if score >= .83 and score-opposite >= .12 and score > matches.get(direction, (0, None))[0]:
                matches[direction] = (score, dict(x=x, y=y, w=w, h=h))
        # A normal-speed sign wins if both signs are visible.
        for direction in ('DOWN', 'UP'):
            if direction in matches:
                score, box = matches[direction]
                return direction, box, score
        return None, None, None
