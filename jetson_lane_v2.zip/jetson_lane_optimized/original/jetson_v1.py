#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Jetson Nano black-tape lane follower. Python 3.6+, OpenCV 4.x.
ESP32 protocol: CTRL,speed,steering / MANUAL,F|B,speed,steering.
Positive steering means LEFT, as in the supplied ESP32 sketch.
"""
import argparse
import itertools
import logging
import threading
import time

import cv2
import numpy as np

# All pixel settings below refer to the resized 320 x 240 image.
WIDTH, HEIGHT = 320, 240
ROI_TOP, ROI_BOTTOM = 0.30, 0.92
TARGET_Y_RATIO = 0.58
SLICES = 28
MIN_LINE_WIDTH, MAX_LINE_WIDTH = 2, 30
BLACK_MAX = 125                 # Upper bound for ROI-only Otsu threshold
MIN_LOCAL_CONTRAST = 14         # Reject broad shadows and uniform dark regions
FIT_TOLERANCE = 4.0
MIN_POINTS = 7
MIN_Y_SPAN = 48                 # Reject five points clustered in a tiny area
MAX_EXTRAPOLATION = 10          # Never extend a short fit 60 pixels for control
EXTENSION_LIMIT = 60            # User-requested automatic visual extension
MIN_LANE_WIDTH, MAX_LANE_WIDTH = 45, 300
TRACK_MAX_JUMP = 24             # Per-boundary jump at target row
TRACK_EXPIRY = 0.45
ACQUIRE_FRAMES = 3
FRAME_TIMEOUT = 0.30
MANUAL_TIMEOUT = 0.60
AUTO_MAX_SPEED, AUTO_MID_SPEED, AUTO_TURN_SPEED = 0.24, 0.21, 0.18
MANUAL_SPEED = 0.30
STEERING_KP, STEERING_KD = 0.62, 0.045
MAX_STEERING, DEAD_ZONE = 28, 5
STEER_RATE = 120.0              # Steering units/second, independent of camera FPS


def black_mask(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (3, 3), 0)
    top, bottom = int(HEIGHT * ROI_TOP), int(HEIGHT * ROI_BOTTOM)
    roi = gray[top:bottom]
    threshold, _ = cv2.threshold(roi, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    threshold = float(np.clip(threshold, 25, BLACK_MAX))
    # Horizontal closing estimates nearby floor brightness without removing thin tape.
    background = cv2.morphologyEx(roi, cv2.MORPH_CLOSE,
                                 np.ones((1, 41), np.uint8))
    contrast = cv2.subtract(background, roi)
    selected = (roi <= threshold) & (contrast >= MIN_LOCAL_CONTRAST)
    mask = np.zeros_like(gray)
    mask[top:bottom] = selected.astype(np.uint8) * 255
    return mask, threshold


def row_candidates(mask):
    points = []
    for y in np.linspace(int(HEIGHT * ROI_TOP), int(HEIGHT * ROI_BOTTOM) - 1,
                         SLICES).astype(int):
        # Majority across three rows reduces isolated floor speckles.
        row = np.count_nonzero(mask[y - 1:y + 2], axis=0) >= 2
        edges = np.diff(np.r_[False, row, False].astype(np.int8))
        starts, ends = np.where(edges == 1)[0], np.where(edges == -1)[0]
        for start, end in zip(starts, ends):
            if MIN_LINE_WIDTH <= end - start <= MAX_LINE_WIDTH and start > 1 and end < WIDTH - 1:
                points.append(((start + end - 1) / 2.0, float(y)))
    return np.asarray(points, dtype=np.float32).reshape(-1, 2)


def line_models(points, target_y):
    """Bounded deterministic RANSAC; score unique scan rows, not raw pixel count."""
    if len(points) < MIN_POINTS or len(points) > 350:
        return []
    x, y = points[:, 0], points[:, 1]
    a, b = np.triu_indices(len(points), 1)
    far = np.abs(y[b] - y[a]) >= MIN_Y_SPAN
    a, b = a[far], b[far]
    if not len(a):
        return []
    if len(a) > 600:
        take = np.random.RandomState(7).choice(len(a), 600, replace=False)
        a, b = a[take], b[take]
    slopes = (x[b] - x[a]) / (y[b] - y[a])
    intercepts = x[a] - slopes * y[a]
    good = np.abs(slopes) < 3.0
    slopes, intercepts = slopes[good], intercepts[good]
    residual = np.abs(x[None, :] - slopes[:, None] * y - intercepts[:, None])
    counts = np.sum(residual <= FIT_TOLERANCE, axis=1)
    models = []
    # Suppress duplicate hypotheses BEFORE refinement. Otherwise the strongest
    # boundary can occupy all 60 slots and hide a slightly shorter opposite line.
    hypotheses = np.column_stack((slopes * target_y + intercepts,
                                  slopes * (target_y + 40) + intercepts))
    remaining = np.argsort(-counts)
    selected = []
    while len(remaining) and len(selected) < 24:
        index = remaining[0]
        if counts[index] < MIN_POINTS:
            break
        selected.append(index)
        distinct = np.max(np.abs(hypotheses[remaining] - hypotheses[index]), axis=1) >= 8
        remaining = remaining[distinct]
    for index in selected:
        inliers = residual[index] <= FIT_TOLERANCE
        # One vote per row; choose the candidate closest to the proposed line.
        ids = np.flatnonzero(inliers)
        ids = ids[np.lexsort((residual[index, ids], y[ids]))]
        _, first = np.unique(y[ids], return_index=True)
        chosen = ids[first]
        if len(chosen) < MIN_POINTS:
            continue
        p = points[chosen]
        coef = np.polyfit(p[:, 1], p[:, 0], 1)
        errors = np.abs(p[:, 0] - np.polyval(coef, p[:, 1]))
        p = p[errors <= FIT_TOLERANCE]
        if len(p) < MIN_POINTS or np.ptp(p[:, 1]) < MIN_Y_SPAN:
            continue
        lo, hi = float(p[:, 1].min()), float(p[:, 1].max())
        if not lo - MAX_EXTRAPOLATION <= target_y <= hi + MAX_EXTRAPOLATION:
            continue
        # Require local evidence where steering is actually measured.
        if np.min(np.abs(p[:, 1] - target_y)) > 12:
            continue
        coef = np.polyfit(p[:, 1], p[:, 0], 1)
        probes = np.polyval(coef, [target_y, target_y + 40])
        if any(np.max(np.abs(probes - m['probes'])) < 8 for m in models):
            continue
        rms = float(np.sqrt(np.mean((p[:, 0] - np.polyval(coef, p[:, 1])) ** 2)))
        models.append(dict(coef=coef, points=p, lo=lo, hi=hi, probes=probes,
                           score=len(p) + (hi - lo) / 20.0 - rms, rms=rms))
        if len(models) >= 10:
            break
    return models


def draw_lane_model(frame, model):
    """Solid = observed fit; dashed = automatic extrapolation (not extra evidence)."""
    lo, hi = int(model['lo']), int(model['hi'])
    for start, end, predicted in ((max(0, lo - EXTENSION_LIMIT), lo, True),
                                  (lo, hi, False),
                                  (hi, min(HEIGHT - 1, hi + EXTENSION_LIMIT), True)):
        step = 16 if predicted else max(1, end - start)
        for y in range(start, end, step):
            next_y = min(y + (8 if predicted else step), end)
            x1, x2 = np.polyval(model['coef'], [y, next_y])
            # OpenCV clips image boundaries; bound coordinates before integer conversion.
            x1, x2 = np.clip([x1, x2], -WIDTH * 2, WIDTH * 3).astype(int)
            cv2.line(frame, (int(x1), y), (int(x2), next_y),
                     (255, 80, 20) if predicted else (255, 200, 0), 1 if predicted else 2)
    for x, y in model['points']:
        cv2.circle(frame, (int(x), int(y)), 2, (0, 255, 255), -1)


class LaneDetector:
    def __init__(self):
        self.previous = None
        self.last_good = -1e9
        self.center = None

    def process(self, frame, now=None):
        now = time.monotonic() if now is None else now
        frame = cv2.resize(frame, (WIDTH, HEIGHT))
        mask, threshold = black_mask(frame)
        points = row_candidates(mask)
        target = int(HEIGHT * TARGET_Y_RATIO)
        models = line_models(points, target)
        if now - self.last_good > TRACK_EXPIRY:
            self.previous = None
            self.center = None
        pairs = []
        for first, second in itertools.combinations(models, 2):
            left, right = sorted((first, second), key=lambda m: m['probes'][0])
            lo, hi = max(left['lo'], right['lo']), min(left['hi'], right['hi'])
            if hi - lo < MIN_Y_SPAN * 0.65:
                continue
            rows = np.array([lo, target, hi])
            lx, rx = np.polyval(left['coef'], rows), np.polyval(right['coef'], rows)
            widths = rx - lx
            # Road boundaries should stay ordered and widen toward the camera.
            if (np.any(lx < -5) or np.any(rx > WIDTH + 5) or np.any(widths < 25)
                    or not MIN_LANE_WIDTH <= widths[1] <= MAX_LANE_WIDTH
                    or widths[2] < widths[0] + 8):
                continue
            boundary = np.array([lx[1], rx[1]])
            penalty = 0.0
            if self.previous is not None:
                change = np.abs(boundary - self.previous)
                if change.max() > TRACK_MAX_JUMP:
                    continue
                penalty = float(change.sum()) * 0.20
            score = left['score'] + right['score'] - penalty
            pairs.append((score, left, right, boundary))
        pairs.sort(key=lambda item: item[0], reverse=True)
        status = 'LOST: insufficient evidence'
        chosen = None
        if pairs:
            chosen = pairs[0]
            # Competing, substantially different lanes must not silently win by one point.
            for alternative in pairs[1:]:
                if (np.max(np.abs(chosen[3] - alternative[3])) > 18
                        and chosen[0] - alternative[0] < 4):
                    chosen = None
                    status = 'LOST: ambiguous lines'
                    break
        result = dict(valid=False, offset=None, status=status, threshold=threshold,
                      points=len(points), timestamp=now)
        if chosen is not None:
            _, left, right, boundary = chosen
            raw_center = float(boundary.mean())
            dt = min(max(now - self.last_good, 0.001), 0.3)
            alpha = 1.0 - np.exp(-dt / 0.055)
            self.center = raw_center if self.center is None else self.center + alpha * (raw_center - self.center)
            self.previous, self.last_good = boundary, now
            offset = self.center - WIDTH / 2.0
            result.update(valid=True, offset=float(offset), status='TRACK',
                          width=float(boundary[1] - boundary[0]),
                          left_points=len(left['points']), right_points=len(right['points']))
            for model in (left, right):
                draw_lane_model(frame, model)
            cv2.circle(frame, (int(self.center), target), 5, (0, 255, 0), -1)
        cv2.rectangle(frame, (1, int(HEIGHT * ROI_TOP)),
                      (WIDTH - 2, int(HEIGHT * ROI_BOTTOM)), (100, 100, 100), 1)
        cv2.line(frame, (WIDTH // 2, 75), (WIDTH // 2, HEIGHT), (255, 255, 255), 1)
        cv2.line(frame, (0, target), (WIDTH - 1, target), (100, 100, 100), 1)
        label = ('OFFSET:{:+.1f} L:{} R:{}'.format(result['offset'], result['left_points'],
                 result['right_points']) if result['valid'] else result['status'])
        cv2.putText(frame, label, (5, 17), cv2.FONT_HERSHEY_SIMPLEX, 0.40,
                    (0, 255, 0) if result['valid'] else (0, 100, 255), 1)
        return frame, mask, result


class SteeringController:
    def __init__(self):
        self.reset()

    def reset(self):
        self.previous = None
        self.last_time = None
        self.rate = 0.0
        self.steer = 0.0

    def update(self, offset, now):
        dt = 1.0 / 30 if self.last_time is None else np.clip(now - self.last_time, 0.005, 0.2)
        derivative = 0.0 if self.previous is None else np.clip((offset - self.previous) / dt, -250, 250)
        self.rate += (1 - np.exp(-dt / 0.09)) * (derivative - self.rate)
        desired = 0.0 if abs(offset) <= DEAD_ZONE else -(STEERING_KP * offset + STEERING_KD * self.rate)
        desired = np.clip(desired, -MAX_STEERING, MAX_STEERING)
        filtered = self.steer + (1 - np.exp(-dt / 0.07)) * (desired - self.steer)
        self.steer += float(np.clip(filtered - self.steer, -STEER_RATE * dt, STEER_RATE * dt))
        self.previous, self.last_time = offset, now
        return int(round(self.steer))


class CommandPolicy:
    """Only real, recent detections may move AUTO. A missing line stops immediately."""
    def __init__(self):
        self.controller = SteeringController()
        self.reset()

    def reset(self):
        self.controller.reset()
        self.good_frames = 0
        self.last_stamp = None
        self.steering = 0

    def command(self, mode, manual, manual_time, detection, now):
        if mode != 'AUTO':
            self.reset()
            if manual == 'STOP' or now - manual_time > MANUAL_TIMEOUT:
                return 'CTRL,0.000,999'
            direction = 'B' if manual == 'B' else 'F'
            steering = {'L': 35, 'R': -35}.get(manual, 0)
            return 'MANUAL,{},{:.3f},{}'.format(direction, MANUAL_SPEED, steering)
        if (not detection or not detection['valid']
                or now - detection['timestamp'] > FRAME_TIMEOUT):
            self.reset()
            return 'CTRL,0.000,999'
        if detection['timestamp'] != self.last_stamp:
            self.good_frames += 1
            self.last_stamp = detection['timestamp']
            self.steering = self.controller.update(detection['offset'], self.last_stamp)
        if self.good_frames < ACQUIRE_FRAMES:
            return 'CTRL,0.000,999'
        magnitude = abs(self.steering)
        speed = AUTO_MAX_SPEED if magnitude <= 7 else AUTO_MID_SPEED if magnitude <= 16 else AUTO_TURN_SPEED
        return 'CTRL,{:.3f},{}'.format(speed, self.steering)


class Car:
    def __init__(self, port=None):
        self.port = port
        self.lock = threading.RLock()
        self.stop = threading.Event()
        self.mode, self.manual = 'MANUAL', 'STOP'
        self.manual_time = 0.0
        self.detection = None
        self.policy = CommandPolicy()
        self.connected = False
        self.command = 'CTRL,0.000,999'
        self.generation = 0
        self.video_condition = threading.Condition()
        self.jpeg, self.mask_jpeg, self.sequence = None, None, 0

    def disarm(self):
        # Caller holds lock. Discard any commands queued before a connection change.
        self.mode, self.manual = 'MANUAL', 'STOP'
        self.generation += 1
        self.detection = None
        self.policy.reset()

    def motor_worker(self):
        import serial
        from serial.tools import list_ports
        connection = None
        next_connect = 0.0
        receive = b''
        try:
            while not self.stop.is_set():
                now = time.monotonic()
                if connection is None and now >= next_connect:
                    next_connect = now + 1.0
                    ports = [self.port] if self.port else [p.device for p in list_ports.comports()
                             if any(s in (p.device + ' ' + (p.description or '')).lower()
                                    for s in ('ttyusb', 'ttyacm', 'cp210', 'ch340', 'ch341'))]
                    if len(ports) != 1:
                        logging.warning('Specify --port: detected %s', ports)
                    else:
                        try:
                            connection = serial.Serial(ports[0], 115200, timeout=0, write_timeout=0.1)
                            self.stop.wait(1.0)  # ESP32 may reset when serial opens
                            connection.reset_input_buffer()
                            with self.lock:
                                self.disarm()
                                self.connected = True
                            logging.info('ESP32 connected; MANUAL STOP. Select AUTO to arm.')
                        except (serial.SerialException, OSError):
                            if connection is not None:
                                connection.close()
                            connection = None
                if connection is not None:
                    try:
                        # Serialize mode changes and motor writes, preventing old AUTO after STOP.
                        with self.lock:
                            self.command = self.policy.command(self.mode, self.manual, self.manual_time,
                                                               self.detection, time.monotonic())
                            connection.write((self.command + '\n').encode('ascii'))
                        receive += connection.read(min(connection.in_waiting, 1024))
                        lines = receive.split(b'\n')
                        receive = lines.pop()[-1024:]
                        for line in lines:
                            text = line.decode('ascii', errors='replace').strip()
                            if text.startswith(('READY', 'EMERGENCY')):
                                with self.lock:
                                    self.disarm()
                            logging.info('ESP32 %s', text)
                    except (serial.SerialException, OSError):
                        connection.close()
                        connection = None
                        receive = b''
                        with self.lock:
                            self.connected = False
                            self.disarm()
                self.stop.wait(0.05)
        finally:
            if connection is not None:
                try:
                    connection.write(b'CTRL,0.000,999\n')
                except (serial.SerialException, OSError):
                    pass
                connection.close()

    def camera_loop(self, camera, display, record=None):
        detector = LaneDetector()
        cap = None
        recorder = None
        last_encode = 0.0
        try:
            while not self.stop.is_set():
                if cap is None:
                    cap = cv2.VideoCapture(camera)
                    cap.set(cv2.CAP_PROP_FRAME_WIDTH, WIDTH)
                    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, HEIGHT)
                    cap.set(cv2.CAP_PROP_FPS, 30)
                    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                # Timestamp BEFORE read/processing so a slow read cannot refresh stale control.
                started = time.monotonic()
                with self.lock:
                    generation = self.generation
                ok, frame = cap.read()
                if not ok or frame is None:
                    with self.lock:
                        self.detection = None
                    cap.release()
                    cap = None
                    detector = LaneDetector()
                    self.stop.wait(0.25)
                    continue
                if record:
                    if recorder is None:
                        recorder = cv2.VideoWriter(record, cv2.VideoWriter_fourcc(*'MJPG'),
                                                   30.0, (WIDTH, HEIGHT))
                        if not recorder.isOpened():
                            raise IOError('Cannot open raw recording: ' + record)
                    recorder.write(cv2.resize(frame, (WIDTH, HEIGHT)))
                annotated, mask, result = detector.process(frame, started)
                with self.lock:
                    if generation == self.generation:
                        self.detection = result
                        if not result['valid']:
                            self.policy.reset()
                    else:
                        detector = LaneDetector()
                    label = '{} {}'.format(self.mode, self.command)
                cv2.putText(annotated, label, (5, 35), cv2.FONT_HERSHEY_SIMPLEX,
                            0.38, (0, 255, 255), 1)
                now = time.monotonic()
                if now - last_encode >= 1.0 / 15:
                    ok1, jpeg = cv2.imencode('.jpg', annotated, [cv2.IMWRITE_JPEG_QUALITY, 75])
                    ok2, debug = cv2.imencode('.jpg', mask)
                    if ok1 and ok2:
                        with self.video_condition:
                            self.jpeg, self.mask_jpeg = jpeg.tobytes(), debug.tobytes()
                            self.sequence += 1
                            self.video_condition.notify_all()
                    last_encode = now
                if display:
                    cv2.imshow('Lane Detection', annotated)
                    cv2.imshow('Black Mask', mask)
                    if cv2.waitKey(1) & 255 == ord('q'):
                        self.stop.set()
        finally:
            with self.lock:
                self.detection = None
            if cap is not None:
                cap.release()
            if recorder is not None:
                recorder.release()
            if display:
                cv2.destroyAllWindows()


HTML = '''<!doctype html><html lang="zh-Hant"><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Jetson Car</title>
<style>body{background:#111;color:white;text-align:center;font-family:Arial}img{width:95%;max-width:640px}
button{font-size:20px;padding:20px;margin:6px;border-radius:12px;touch-action:none;user-select:none}
.stop{background:#ff7766}a{color:#6cf}</style>
<h2>Jetson Car</h2><img src="/video_feed"><p id="status">Connecting...</p>
<button onclick="mode('AUTO')">AUTO</button><button onclick="mode('MANUAL')">MANUAL</button><br>
<button data-cmd="F">前進</button><br><button data-cmd="L">左轉</button>
<button class="stop" onclick="halt()">STOP</button><button data-cmd="R">右轉</button><br>
<button data-cmd="B">後退</button><p><a href="/mask_feed" target="_blank">黑線遮罩</a></p>
<script>
let held='STOP', busy=false, epoch=0;
async function post(path,data){return fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});}
async function manual(){if(busy||held==='STOP')return;busy=true;try{await post('/control',{command:held,epoch});}finally{busy=false;}}
async function refresh(){try{let s=await(await fetch('/status')).json();epoch=s.epoch;
document.getElementById('status').textContent=s.mode+' | '+s.lane+' | '+(s.connected?'ESP32 已連線':'ESP32 未連線');}catch(e){}}
function halt(){held='STOP';post('/control',{command:'STOP'}).then(refresh);}
async function mode(m){held='STOP';await post('/mode',{mode:m});await refresh();}
document.querySelectorAll('[data-cmd]').forEach(b=>{b.onpointerdown=e=>{e.preventDefault();b.setPointerCapture(e.pointerId);held=b.dataset.cmd;manual();};
b.onpointerup=halt;b.onpointercancel=halt;b.onlostpointercapture=()=>{if(held!=='STOP')halt();};});
setInterval(manual,150);setInterval(refresh,700);refresh();
window.addEventListener('blur',()=>{if(held!=='STOP')halt();});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&held!=='STOP')halt();});
</script></html>'''


def make_app(car):
    from flask import Flask, Response, jsonify, request
    app = Flask(__name__)

    @app.route('/')
    def index():
        return HTML

    @app.route('/status')
    def status():
        with car.lock:
            fresh = car.detection and time.monotonic() - car.detection['timestamp'] <= FRAME_TIMEOUT
            return jsonify(mode=car.mode, connected=car.connected, command=car.command,
                           epoch=car.generation,
                           lane=car.detection['status'] if fresh else 'NO FRESH FRAME')

    @app.route('/mode', methods=['POST'])
    def mode():
        data = request.get_json(silent=True)
        value = data.get('mode') if isinstance(data, dict) else None
        if value not in ('AUTO', 'MANUAL'):
            return jsonify(ok=False), 400
        with car.lock:
            if value == 'AUTO' and not car.connected:
                return jsonify(ok=False, error='ESP32 not connected'), 409
            car.disarm()
            car.mode = value
        return jsonify(ok=True)

    @app.route('/control', methods=['POST'])
    def control():
        data = request.get_json(silent=True)
        value = data.get('command') if isinstance(data, dict) else None
        if value not in ('F', 'B', 'L', 'R', 'STOP'):
            return jsonify(ok=False), 400
        with car.lock:
            if value == 'STOP':
                car.disarm()  # STOP works in AUTO, even when no manual key was held.
            else:
                if car.mode != 'MANUAL' or data.get('epoch') != car.generation or not car.connected:
                    return jsonify(ok=False), 409
                car.manual, car.manual_time = value, time.monotonic()
        return jsonify(ok=True)

    def frames(mask=False):
        previous = -1
        while not car.stop.is_set():
            with car.video_condition:
                car.video_condition.wait_for(lambda: car.sequence != previous or car.stop.is_set(), timeout=1)
                if car.sequence == previous:
                    continue
                previous = car.sequence
                jpeg = car.mask_jpeg if mask else car.jpeg
            if jpeg is not None:
                yield b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + jpeg + b'\r\n'

    @app.route('/video_feed')
    def video():
        return Response(frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

    @app.route('/mask_feed')
    def mask():
        return Response(frames(True), mimetype='multipart/x-mixed-replace; boundary=frame')
    return app


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--camera', type=int, default=0)
    parser.add_argument('--port', help='e.g. /dev/ttyUSB0; required if multiple serial devices exist')
    parser.add_argument('--display', action='store_true', help='Enable local OpenCV windows')
    parser.add_argument('--image', help='Offline raw-camera image; does not open serial or web server')
    parser.add_argument('--video', help='Offline raw-camera video; does not open serial or web server')
    parser.add_argument('--record', help='Record unannotated camera frames to an .avi file')
    parser.add_argument('--output', default='lane_debug.jpg')
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')
    cv2.setNumThreads(2)
    if args.image:
        frame = cv2.imread(args.image)
        if frame is None:
            parser.error('Cannot read image')
        annotated, mask, result = LaneDetector().process(frame)
        if not cv2.imwrite(args.output, annotated) or not cv2.imwrite(args.output + '.mask.png', mask):
            raise IOError('Cannot write output')
        print(result)
        return
    if args.video:
        detector = LaneDetector()
        source = cv2.VideoCapture(args.video)
        if not source.isOpened():
            parser.error('Cannot read video')
        fps = source.get(cv2.CAP_PROP_FPS)
        fps = fps if np.isfinite(fps) and 1 <= fps <= 120 else 30.0
        destination = args.output if args.output.lower().endswith('.avi') else args.output + '.avi'
        writer = cv2.VideoWriter(destination, cv2.VideoWriter_fourcc(*'MJPG'), fps, (WIDTH, HEIGHT))
        if not writer.isOpened():
            source.release()
            raise IOError('Cannot write video')
        count, valid = 0, 0
        try:
            while True:
                ok, frame = source.read()
                if not ok:
                    break
                annotated, _, result = detector.process(frame, count / fps)
                writer.write(annotated)
                count += 1
                valid += int(result['valid'])
        finally:
            source.release()
            writer.release()
        print('Processed {} frames, {} valid; {}'.format(count, valid, destination))
        return
    car = Car(args.port)
    app = make_app(car)
    logging.getLogger('werkzeug').setLevel(logging.ERROR)
    motor = threading.Thread(target=car.motor_worker, daemon=True)
    motor.start()
    threading.Thread(target=lambda: app.run(host='0.0.0.0', port=5000, threaded=True,
                     debug=False, use_reloader=False), daemon=True).start()
    try:
        car.camera_loop(args.camera, args.display, args.record)
    except KeyboardInterrupt:
        pass
    finally:
        car.stop.set()
        with car.video_condition:
            car.video_condition.notify_all()
        motor.join(timeout=2.0)


if __name__ == '__main__':
    main()
